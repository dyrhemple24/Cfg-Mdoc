using UnityEngine;

public class AdvancedAimAssistScript : MonoBehaviour
{
    public Transform target; // 
    public float assistStrength = 0.1f; // 
    public float maxAssistAngle = 30f; // 
    public LayerMask targetMask; // 
    public LayerMask obstacleMask; // 
    
    private Camera mainCamera;

    private void Start()
    {
        mainCamera = Camera.main;
    }

    void Update()
    {
        AimAssist();
    }

    void AimAssist()
    {
        Vector3 targetDirection = target.position - transform.position;
        if (IsTargetVisible() && IsWithinAimAngle(targetDirection))
        {
            float step = assistStrength * Time.deltaTime;
            
            Vector3 newDirection = Vector3.RotateTowards(transform.forward, targetDirection, step, 0.0f);
            transform.rotation = Quaternion.LookRotation(newDirection);
        }
    }


    private bool IsTargetVisible()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, (target.position - transform.position).normalized, out hit, Mathf.Infinity, obstacleMask))
        {

            if (hit.transform == target)
            {
                return true;
            }
        }
        return false;
    }


    private bool IsWithinAimAngle(Vector3 targetDirection)
    {
        float angleToTarget = Vector3.Angle(mainCamera.transform.forward, targetDirection);
        return angleToTarget < maxAssistAngle;
    }
}